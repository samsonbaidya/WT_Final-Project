<?php
require_once "pdo.php";
require_once "util.php";
session_start();
if(isset($_SESSION['user_id'])){
    unset($_SESSION['user_id']);
}
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Polling System</title>
  </head>
  <body style="margin:20px;">
    <div class="container">
      <h1>Online Polling System</h1>
      <h2> <span style="margin-left: 20px;"></span> <a href="login.php">Log In </a> <span style="margin-left: 20px;"></span> <?php echo "|"; ?> <span style="margin-left: 20px;"></span> <a href="signup.php"> Sign up </a> </h2>

      <?php
        flashMessages();
      ?>

      <h4>Rules for Signup</h4>
      <ul>
        <li>
          <p>You must know the <span style="font-weight: bold;"> Reference number</span> to Signup. Contact
          <span style="font-weight: bold;"> HR Members </span> if you don't. </p>
        </li>
        <li>
            <p>Signup option is only for <span style="font-weight: bold;"> HR Members.</span> Don't Signup if you are not HR Member. </p>
        </li>
      </ul>
    </div>
  </body>
</html>

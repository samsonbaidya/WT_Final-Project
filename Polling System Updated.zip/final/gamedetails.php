<?php 

	$key = $_GET['name'];
	$connection=mysqli_connect('localhost','root','','game');

	$sql = "SELECT * FROM game_name WHERE name ='$key'";
	$result = mysqli_query($connection,$sql);
	$row = mysqli_fetch_assoc($result)

 ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Game List Page</title>
</head>
<body>
	<div class="container">	
        
		
        <p><strong>Game ID:</strong> <?php echo $row['id']; ?></p>
        <p><strong>Game Name:</strong> <?php echo $row['name']; ?></p> 
        <p><strong>Game Type:</strong> <?php echo $row['type']; ?></p> 
        <p><strong>Vote Count:</strong> <?php echo $row['count']; ?></p> 

        
	</div>
    
</body>
</html>
<?php
	$key=$_GET["key"];
	$s="localhost";
	$u="root";
	$p="";
	$d="game";
	$conn=mysqli_connect($s,$u,$p,$d);
	$query="SELECT name FROM game_name WHERE name LIKE '%$key%'";
	$rs=mysqli_query($conn,$query);
?>

<table>
	<?php
		while ($row=mysqli_fetch_assoc($rs)) {
			echo "<tr>";
			echo '<td><a href="gamedetails.php?name='.$row["name"].'" class="btn btn-success">'.$row["name"].'</a></td>';
			echo "</tr>";
		}
	?>
</table>
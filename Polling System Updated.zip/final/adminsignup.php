<!DOCTYPE html>
<html>
<head>
      <title>Admin Sign UP</title>
      <link rel="stylesheet"  href="bbreg.css">
      <body style="background-image: url(bbreg.jpg);  background-repeat: no-repeat; background-attachment: fixed;background-size: 100% 100%; ">  
      <script>
function showHint(str) {
  if (str.length == 0) {
    document.getElementById("txtHint").innerHTML = "";
    return;
  } else {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("txtHint").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET", "repo/gethint.php?q=" + str, true);
    xmlhttp.send();
  }
}
</script>
</head> 
<body>
        
    
      <!--container /login box-->
      <div class="container">
      <form method="post" action="adminsignup.php"> 
        <h1 class="neon">Online Polling System</h1>
        <h2 class="neon1">ADMIN SIGN UP</h2>
        <div class="textbox">
          <i class="fa fa-user-o" aria-hidden="true"></i>
          <input type="text" placeholder="Name"  name="name" required>
        </div>
       
        <div class="textbox">
          <i class="fa fa-user-o" aria-hidden="true"></i>
        <input type="text" placeholder="User Name"  name="username" onkeyup="showHint(this.value)" required><br>
          <p class="sp"> Suggestions: <span id="txtHint"></span></p>
        </div>
      
        <div class="textbox">
          <i class="fa fa-envelope" aria-hidden="true"></i>
          <input type="email" placeholder="Email"  name="email" required>
        </div>
        <div class="textbox">
          <i class="fa fa-phone" aria-hidden="true"></i>
          <input type="text" placeholder="Phone Number"  name="number" required>
        </div>
        
        <div class="textbox">
          <i class="fa fa-key fa-fw"></i>
          <input type="password"  placeholder="Password" name="password" required>      
        </div> 
        <div class="textbox">
          <i class="fa fa-key fa-fw"></i>
          <input type="password"  placeholder="Re-Type Password" name="cpassword" required>      
        </div> </br> 
        <div class="center" >
        <input type="checkbox" name="Remember" ><i id="rem">I agree all the terms and Conditions </i>     
    
        </div>
            
        <div>
        <center>


           <?php
                $db = mysqli_connect("localhost", "root", "", "pollingsystem");
                if(isset($_POST['submit'])) {
                $name = $_POST['name'];
                $username = $_POST['username'];
                $email = $_POST['email'];
                $number = $_POST['number'];
                $password = $_POST['password'];
                $cpassword = $_POST['cpassword'];
                if($password == $cpassword){
                        $sql = "INSERT INTO admin(name, username, number, email, password) VALUES('$name', '$username', '$number', '$email', '$cpassword')";
                        mysqli_query($db, $sql); //data is inserted into the database
                        echo "<script>
                                  alert('Admin signup successful');
                              </script>";
                }else{
                        echo "Password doesn't match";
                }
                }
                elseif(isset($_POST['cancel'])) 
  {
    header("location: login.php");
  }
        ?>

       <a href="#" id="login">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <!--NEED CSS-->
            <input style="background-color:Green"type="submit" name="submit" value="Signup">
            <!-- NEED CSS-->
          </a>
          <a href="login.php" id="login">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <!-- NEED CSS 
            <input style="background-color:Red"type="submit" name="back" value="Cancel"> 
            <a href="homepage.html">Cancel</a>-->
            <input style="background-color:Green"type="submit" name="cancel" value="Back">
            
            <!-- NEED CSS-->
          </a1>
        </center>
        <br>  
        </div>  
        

        </form>
   
        </div>
        <footer id="main-footer">
        <hr>
        <p>Copyright &copy; Online Polling System 2020  </p>
      </footer>
    
      
</body>
   
<html>

<!DOCTYPE html>
<html>
<head>
      <title>Sign UP</title>
      <link rel="stylesheet"  href="breg.css">
      <body style="background-image: url(breg.jpg);  background-repeat: no-repeat; background-attachment: fixed;background-size: 100% 100%; ">
            <script>
function showHint(str) {
  if (str.length == 0) {
    document.getElementById("txtHint").innerHTML = "";
    return;
  } else {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("txtHint").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET", "repo/gethint.php?q=" + str, true);
    xmlhttp.send();
  }
}
</script>
        
    
       
</head> 
<body>
        
    
      <!--container /login box-->
      <div class="container">
      <form method="post" action="usersignup.php">
        <h1 class="neon">Online Polling System</h1>
        <h2 class="neon1">SIGN UP</h2>
        <div class="textbox">
          <i class="fa fa-user-o" aria-hidden="true"></i>
          <input type="text" placeholder="First Name"  name="fname" required>
        </div>
        <div class="textbox">
          <i class="fa fa-user-o" aria-hidden="true"></i>
          <input type="text" placeholder="Last Name"  name="lname" required>
        </div>
        <div class="textbox">
          <i class="fa fa-user-o" aria-hidden="true"></i>
          <input type="text" placeholder="User Name"  name="uname" required>
        </div>
         <!-- gender adding, NEED CSS -->
        <div>
            <i class="fa fa-transgender-alt" aria-hidden="true"></i>
            <label for="gender">Gender</label>
            <input type="radio" name="gender" value="male" required>
            <label for="male">Male</label>
            <input type="radio" name="gender" value="female" required>
            <label for="female">Female</label>
            <input type="radio" name="gender" value="other" required>
            <label for="other">Other</label>
        </div> 
        <!-- gender adding, NEED CSS -->
         <div class="textbox">
          <i class="fa fa-child" aria-hidden="true"></i>
          <input type="tel" placeholder="Age"  name="age" required>
        </div>
      
        <div class="textbox">
          <i class="fa fa-envelope" aria-hidden="true"></i>
          <input type="email" placeholder="Email"  name="email" required>
        </div>
        <div class="textbox">
          <i class="fa fa-phone" aria-hidden="true"></i>
          <input type="text" placeholder="Phone Number"  name="number" required>
        </div>
        <div class="textbox">
          <i class="fa fa-home" aria-hidden="true"></i>
          <input type="area" placeholder="Present Address"  name="address" required>        
        </div>
        <div class="textbox">
          <i class="fa fa-key fa-fw"></i>
          <input type="password"  placeholder="Password" name="password" required>      
        </div> 
        <div class="textbox">
          <i class="fa fa-key fa-fw"></i>
          <input type="password"  placeholder="Re-Type Password" name="cpassword">      
        </div> 
        <div class="center" >
        <input type="checkbox" name="Remember" checked="checked" ><i id="rem">I agree all the terms and Conditions </i>     
    
        </div>
        
          <?php
                $db = mysqli_connect("localhost", "root", "", "pollingsystem");
                if(isset($_POST['submit'])) {
                  session_start();
                  $fname = $_POST['fname'];
                  $lname = $_POST['lname'];
                  $uname = $_POST['uname'];
                  $email = $_POST['email'];
                  $number = $_POST['number'];
                  $gender = $_POST['gender'];
                  $age = $_POST['age'];
                  $address = $_POST['address'];
                  $password = $_POST['password'];
                  $cpassword = $_POST['cpassword'];
                  $value = 18;
                  if($age >= $value){
                          if($password == $cpassword){
                              $sql = "INSERT INTO user(firstname, lastname, username, email, number, gender, age, address, password ) VALUES('$fname', '$lname', '$uname', '$email', '$number', '$gender', '$age', '$address', '$cpassword')";
                              	mysqli_query($db, $sql); //data is inserted into the database
                              /*echo "<script>
                                  alert('User signup successful');
                                </script>";*/
                                $_SESSION['fname']=$fname;
		                        $_SESSION['lname']=$lname;
		                        $_SESSION['uname']=$uname;
		                       	$_SESSION['email']=$email;		 
		                       	$_SESSION['number']=$number;
		                        $_SESSION['gender']=$gender;
		                        $_SESSION['age']=$age;
		                        $_SESSION['address']=$address;
		                        //$_SESSION['password']=$password;
		                        header("location: usersuccess.php");
		                        }else{
		                              echo "Password doesn't match";
		                            }
                  }
                  else{
                    echo "Your age must be 18 or above for signup";
                  }
                }
                elseif(isset($_POST['cancel'])) 
  {
    header("location: login.php");
  }
        ?>
        

      <div>
        <center>
          <a href="login.php" id="login">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
        <input style="background-color:Green" class="neon2" type="submit" name="cancel" value="Back">
          </a>
          
    
          <a href="#" id="login">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <input style="background-color:Green" type="submit" name="submit" value="Signup"  >
          </a>

        </center>
        <br>  
        </div>    
        

        </form>
   
        </div>
        <footer id="main-footer">
        <hr>
        <p>Copyright &copy; Online Polling System 2020  </p>
      </footer>
    
      
</body>
   
<html>

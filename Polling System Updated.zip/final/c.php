<!DO`CTYPE html>
<html>
<head>
	<title> new file</title>
</head>
<body>
	<?php $result=0;
	?>
	 
	<form action="c.php" method="POST">
	<div style=" width: 136px; height: 103px; float: left;">
 	<img src="phy1.jpg" style=" height: 100% ;width: 100%">
 	    
 	
 </div >

 
 <div style="  height: 103px; background-color: blueviolet; margin: 0px">
 	<p style="text-align: center; font-size:300%;padding-top: 16px"><b>Programming in Phyton</b></p>
 	<p style="text-align: center; font-size: 116%"> Each Question Contains 2 Points</p>
 	

 </div>
<br>
 <br>
 <p  style="text-align: center;">Time: <mark>15</mark> Mins</p>
 <hr>

<!--ques-1-->
		<div>
 	<label style="margin-left:20PX">1: What is output for−'search'. find('S') ?</label><br>
 	<input type="radio" name="ques1" value="A" style="margin-left:40PX" >s
 	<?php
	

   if(isset($_POST['submit']))
	{

		if($_POST['ques1']=='A')
		{    
			
       echo "❌";
       

		}
	}
	?>
	<br>
 	<input type="radio" name="ques1" value="B" style="margin-left:40PX">-1
 	<?php
	   if(isset($_POST['submit']))
	   { 
	      
	       echo "✔️";

	       
		{
			if($_POST['ques1']=='B')
			{   
			$result=$result+2;	
	        
			}
			
			
		}
		}
		?>
		<br>
 	<input type="radio" name="ques1" value="C" style="margin-left:40PX">' '
 	<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques1']=='C')
		{    
			
       echo "❌";
       

		}
	}
	?>
	<br>
 	<input type="radio" name="ques1" value="D" style="margin-left:40PX">None of the above
 	<?php

   if(isset($_POST['submit']))
	{
		if($_POST['ques1']=='D')
		{    
			
       echo "❌";
       
		}
	}
	?>
	<br>
 </div>
	<br>
	
 <!--ques-2-->
 <div>
 	<label style="margin-left:20PX">2: What is output for −b = [11,13,15,17,19,21] ptint(b[::2])</label><br>
 	<input type="radio" name="ques2" value="A" style="margin-left:40PX">[19,21]<td>
 			<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques2']=='A')
		{    
			
       echo "❌";
       

		}
	}
	?>
 		<br>

 	<input type="radio" name="ques2" value="B" style="margin-left:40PX">[11,15]
    <?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques2']=='B')
		{    
			
       echo "❌";
       

		}
	}
	?>
 	<br>
 	<input type="radio" name="ques2" value="C" style="margin-left:40PX">[11,15,19]
 	<?php
	   if(isset($_POST['submit']))
	   {
	      
	       echo "✔️";
	       
		{
			if($_POST['ques2']=='C')
			{   
			$result=$result+2;	
	        
			}
			
			
		}
		}
		?>
 	<br>
 	<input type="radio" name="ques2" value="b" style="margin-left:40PX">[13,17,21]
 	<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques2']=='D')
		{    
			
       echo "❌";
       

		}
	}
	?><br>
 </div>
 <br>
 <!--ques-3-->
 <div>
 	<label style="margin-left:20PX">3: Which of the following function convert a string to a float in python?</label><br>
 	<input type="radio" name="ques3" value="A" style="margin-left:40PX">int(x [,base])
 		<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques3']=='A')
		{    
			
       echo "❌";
       

		}
	}
	?>
 		<br>
 	<input type="radio" name="ques3" value="B" style="margin-left:40PX">long(x [,base] )
 	 <?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques3']=='B')
		{    
			
       echo "❌";
       

		}
	}
	?>
 	<br>
 	<input type="radio" name="ques3" value="C" style="margin-left:40PX">float(x)
 	<?php
	   if(isset($_POST['submit']))
	   {
	      
	       echo "✔️";
	       
		{
			if($_POST['ques3']=='C')
			{   
			$result=$result+2;	
	        
			}
			
			
		}
		}
		?><br>
 	<input type="radio" name="ques3" value="D" style="margin-left:40PX">str(x)
 <?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques3']=='D')
		{    
			
       echo "❌";
       

		}
	}
	?>
 	<br>
 </div>
 <br>
  <!--ques-4-->
 <div>
 	<label style="margin-left:20PX">4: How can we check whether the object is instance of class or not. Let us consider an object O which is instance of class B.
 	</label><br>
 	<input type="radio" name="ques4" value="A" style="margin-left:40PX">B.isinstanc(O)
 	<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques4']=='A')
		{    
			
       echo "❌";
       

		}
	}
	?>
 	<br>
 	<input type="radio" name="ques4" value="B" style="margin-left:40PX">O.isinstance(B)
 	<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques4']=='B')
		{    
			
       echo "❌";
       

		}
	}
	?>
 	<br>
 	<input type="radio" name="ques4" value="C" style="margin-left:40PX">isinstance(O,B)
 	<?php
	   if(isset($_POST['submit']))
	   {
	      
	       echo "✔️";
	       
		{
			if($_POST['ques4']=='C')
			{   
			$result=$result+2;	
	        
			}
			
			
		}
		}
		?><br>
 	<input type="radio" name="ques4" value="D" style="margin-left:40PX">isinstance(B,O)
 	<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques4']=='D')
		{    
			
       echo "❌";
       

		}
	}
	?><br>
 </div>
 <br>
 <!--ques-5-->
 <div>
 	<label style="margin-left:20PX">5: What command is used to insert 6 in a list ‘‘L’’ at 3rd position ?</label><br>
 	<input type="radio" name="ques5" value="A" style="margin-left:40PX">L.insert(2,6)
 	<?php
	   if(isset($_POST['submit']))
	   {
	      
	       echo "✔️";
	       
		{
			if($_POST['ques5']=='A')
			{   
			$result=$result+2;	
	        
			}
			
			
		}
		}
		?>
 	<br>
 	<input type="radio" name="ques5" value="B" style="margin-left:40PX">L.insert(3,6)
 	<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques5']=='B')
		{    
			
       echo "❌";
       

		}
	}
	?><br>
 	<input type="radio" name="ques5" value="C" style="margin-left:40PX">L.add(3,6)
 	<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques5']=='C')
		{    
			
       echo "❌";
       

		}
	}
	?><br>
 	<input type="radio" name="ques5" value="D" style="margin-left:40PX"> L.append(2,6)
 	<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques5']=='D')
		{    
			
       echo "❌";
       

		}
	}
	?><br>
 	</div>
 	<br>
<!--ques-6-->
 	<div>
	 	<label style="margin-left:20PX">6: Which options are correct to create an empty set in Python?</label><br>
		<input type="radio" name="ques6" value="A" style="margin-left:40PX">{}
		<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques6']=='A')
		{    
			
       echo "❌";
       

		}
	}
	?><br>
	 	<input type="radio" name="ques6" value="B" style="margin-left:40PX">()
	 	<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques6']=='B')
		{    
			
       echo "❌";
       

		}
	}
	?>
	 	<br>
	 	<input type="radio" name="ques6" value="C" style="margin-left:40PX">[]
	 	<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques6']=='C')
		{    
			
       echo "❌";
       

		}
	}
	?>
	 	<br>
	 	<input type="radio" name="ques6" value="D" style="margin-left:40PX">set()
	 	<?php
	   if(isset($_POST['submit']))
	   {
	      
	       echo "✔️";
	       
		{
			if($_POST['ques6']=='D')
			{   
			$result=$result+2;	
	       
			}
			
			
		}
		}
		?>

	 	<br>
    </div>
 	<br>
 	<!--ques-7-->
 <div>
 	<label style="margin-left:20PX">7: Suppose you are using a grid manager then which option is best suitable to place a component in multiple rows and columns?</label><br>
 	<input type="radio" name="ques7" value="A" style="margin-left:40PX">Columnspan and rowspan
 	<?php
	   if(isset($_POST['submit']))
	   {
	      
	       echo "✔️";
	       
		{
			if($_POST['ques7']=='A')
			{   
			$result=$result+2;	
	        
			}
			
			
		}
		}
		?>

 	<br>
 	<input type="radio" name="ques7" value="B" style="margin-left:40PX">Only row
 	<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques7']=='B')
		{    
			
       echo "❌";
       

		}
	}
	?>
 	<br>
 	<input type="radio" name="ques7" value="C" style="margin-left:40PX">Only column
<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques7']=='C')
		{    
			
       echo "❌";
       

		}
	}
	?>
 	<br>
 	<input type="radio" name="ques7" value="D" style="margin-left:40PX">Only rowspan
 	<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques7']=='D')
		{    
			
       echo "❌";
       

		}
	}
	?><br>
 </div>
 <br>
 <!--ques-8-->
 <div>
 	<label style="margin-left:20PX">8: Which of these is not a core data type?</label><br>
 	<input type="radio" name="ques8" value="A" style="margin-left:40PX">Lists
 	<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques8']=='A')
		{    
			
       echo "❌";
       

		}
	}
	?>
 	<br>
 	<input type="radio" name="ques8" value="B" style="margin-left:40PX">Dictionary
 	<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques8']=='B')
		{    
			
       echo "❌";
       

		}
	}
	?>
 	<br>
 	<input type="radio" name="ques8" value="C" style="margin-left:40PX">Tuples
 	<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques8']=='C')
		{    
			
       echo "❌";
       

		}
	}
	?>
 	<br>
 	<input type="radio" name="ques8" value="D" style="margin-left:40PX">Class
 	<?php
	   if(isset($_POST['submit']))
	   {
	      
	       echo "✔️";
	       
		{
			if($_POST['ques8']=='D')
			{   
			$result=$result+2;	
	        
			}
			
			
		}
		}
		?>
 	<br>

 </div>
 <br>
 <!--ques9-->
 <div>
 	<label style="margin-left:20PX">9:What is called when a function is defined inside a class?</label><br>
 	<input type="radio" name="ques9" value="A" style="margin-left:40PX">Module
 	<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques9']=='A')
		{    
			
       echo "❌";
       

		}
	}
	?><br>
 	<input type="radio" name="ques9" value="B" style="margin-left:40PX">Class
 	<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques9']=='B')
		{    
			
       echo "❌";
       

		}
	}
	?><br>
 	<input type="radio" name="ques9" value="C" style="margin-left:40PX">Another Function
 	<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques9']=='C')
		{    
			
       echo "❌";
       

		}
	}
	?><br>
 	<input type="radio" name="ques9" value="D" style="margin-left:40PX">Method
 	<?php
	   if(isset($_POST['submit']))
	   {
	      
	       echo "✔️";
	       
		{
			if($_POST['ques9']=='D')
			{   
			$result=$result+2;	
	        

			}
			
			
		}
		}
		?>
 	<br>
 </div>
 <br>
 <!--ques-10-->
<div>
 	<label style="margin-left:20PX">10: Suppose list1 is [3, 4, 5, 20, 5, 25, 1, 3], what is list1 after list1.pop(1)?</label><br>
 	<input type="radio" name="ques10" value="A" style="margin-left:40PX ">[3, 4, 5, 20, 5, 25, 1, 3]
<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques10']=='A')
		{    
			
       echo "❌";
       

		}
	}
	?>
 	<br>
 	<input type="radio" name="ques10" value="B" style="margin-left:40PX">[1, 3, 3, 4, 5, 5, 20, 25]
 	<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques10']=='B')
		{    
			
       echo "❌";
       

		}
	}
	?>
 	<br>
 	<input type="radio" name="ques10" value="C" style="margin-left:40PX">[3, 5, 20, 5, 25, 1, 3]
 		<?php
	   if(isset($_POST['submit']))
	   {
	      
	       echo "✔️";
	       
		{
			if($_POST['ques10']=='C')
			{   
			$result=$result+2;	
	        
			}
			
			
		}
		}
		?>
 	<br>
 	<input type="radio" name="ques10" value="D" style="margin-left:40PX">[1, 3, 4, 5, 20, 5, 25]
 	<?php
	

   if(isset($_POST['submit']))
	{
		if($_POST['ques10']=='D')
		{    
			
       echo "❌";
       

		}
	}
	?><br>
 </div>

 <br>
 <div align="center">
 	<input type="submit" name="submit" style="color: black;background-color : green"><br>
 </div>
		
	<div align="center" style="color : red">
		<?php
		 if(isset($_POST['submit']))
		 {
		 	echo'<h3>';
		 	echo "You have gain ".$result;
		 	if ($result>=1) {
		 		echo" points";
		 	} else {
		 		echo" point";
		 	}
		 	echo'</h3>';
		 }
        
		?>

	</div>
		
    </form>
</body>
</html>



























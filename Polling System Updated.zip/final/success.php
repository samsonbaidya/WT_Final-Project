<?php
session_start();
if(isset($_SESSION['email'])) {   
    echo "Update Successful.<br>";
    echo "Please logout and log back in.<br>";
    ;
}else {
    header("location: login.php");
}
?>
<!DOCTYPE html>
<html>
    <head>
    <title>Sign Up</title>
    <link rel="stylesheet" type="text/css" href="success.css">
    </head>
    <body> 
         <div class="container">

  <center><header class="rem">Online Polling System</header></center>
     <form method="POST" action="otp.php" id="form"> 
        <h1 class="neon">logout</h1>
    <div>
          <center>
           <div >
        <a  href="login.php" id="admin">
              <span></span>
              <span></span>
              <span></span>
              <span></span>
             lOGOUT
            </a>
       
            </div>
          </center>
           
        </div>  
  
      </form>
</div>
<footer id="main-footer">
        <hr>
        <p>Copyright &copy; Online Polling System 2020  </p>
      </footer>  
</body>
</html>
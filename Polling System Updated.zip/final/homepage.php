<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Homepage</title>
	<link rel="stylesheet" href="homepage.css">

	<script>
		function search()
		{
			http = new XMLHttpRequest();
			var search_word=document.getElementById("search_input").value;
			http.onreadystatechange=function()
			{
				if(http.readyState == 4 && http.status == 200)
				{
					document.getElementById("search_result").innerHTML=http.responseText;
				}
			}
			http.open("GET","search.php?key="+search_word,true);
			http.send();
		}
	</script>


</head>
<body>
	<div class="query">ONLINE POLLING SYSTEM</div>
	<nav class="main-menu">
	 			<div class="logo">
	 			</div>
			 	<ul>
                    <li><a class="current" href="#">Home</a></li>
				
					
					<li><a href="#">SignUp</a></li>
					<li><a href="#">LogIn</a></li>
					<li><a href="#">Result</a></li>
					<li><a href="#Multiplayer">Multiplayer Games</a></li>
                    <li><a href="#Singleplayer">Single Player Games</a></li>
					<li><a href="#Contacts">Contacts</a></li>
					<li>
					</div>
						<input type="text" id="search_input" onkeyup="search()" placeholder="search game">
						<div id="search_result">
					</div>
					</li>
				</ul>
	 		</nav>
	 <header class="header-part">
	 	<div class="header-overlay">
	 		<div class="kilibili">
	 			<div class="content text-center">
					 <h1>WELCOME!</h1>
					 <h3>This Polling System Is About Online Game</h3>
					 <p>click your favourite game to vote</p>
					 <a href="vote.php">Vote Now</a>
				</div>
	 		</div>
	 	</div>
	 </header>

	 <section id="Multiplayer">
		<h1>Multiplayer Games</h1><br>
		
		<div class="services">
			<div class="ser-container">
			<div class="service-item">
				<div class="pic-size">

					<a href="gtav.php" target="_blank"><img src="img/m1.jpg" height="200px" width="200px"></a>

				</div>
				<div class="service-content">GTA V</p>			
				</div>
			</div>
		</div>

		<div class="services">
			<div class="ser-container">
			<div class="service-item">
				<div class="pic-size">
					<a href="apexlegends.php" target="_blank"><img src="img/m2.jpg" height="200px" width="200px"></a>
				</div>
				<div class="service-content">Apex Legends</p>		
				</div>
			</div>
		</div>

		<div class="services">
			<div class="ser-container">
			<div class="service-item">
				<div class="pic-size">
					<a href="pubg.php" target="_blank"><img src="img/m3.jpg" height="200px" width="200px"></a>
				</div>
				<div class="service-content">PUBG</p>		
				</div>
			</div>
		</div>

		<div class="services">
			<div class="ser-container">
			<div class="service-item">
				<div class="pic-size">
					<a href="fifa20.php" target="_blank"><img src="img/m4.jpg" height="200px" width="200px"></a>
				</div>
				<div class="service-content">FIFA 20</p>		
				</div>
			</div>
		</div>

		<div class="services">
			<div class="ser-container">
			<div class="service-item">
				<div class="pic-size">
					<a href="diablo.php" target="_blank"><img src="img/m5.jpg" height="200px" width="200px"></a>
				</div>
				<div class="service-content">Diablo</p>		
				</div>
			</div>
		</div>


	</section><br><hr>

	<section id="Singleplayer">
		<h1>Single Player Games</h1><br>

		<div class="services">
			<div class="ser-container">
			<div class="service-item">
				<div class="pic-size">
					<a href="the witcher.php" target="_blank"><img src="img/m6.jpg" height="200px" width="200px"></a>
				</div>
				<div class="service-content">The Witcher</p>		
				</div>
			</div>
		</div>

		<div class="services">
			<div class="ser-container">
			<div class="service-item">
				<div class="pic-size">
					<a href="sekiro.php" target="_blank"><img src="img/m7.jpg" height="200px" width="200px"></a>
				</div>
				<div class="service-content">SEKIRO</p>		
				</div>
			</div>
		</div>

		<div class="services">
			<div class="ser-container">
			<div class="service-item">
				<div class="pic-size">
					<a href="god of war.php" target="_blank"><img src="img/m8.jpg" height="200px" width="200px"></a>
				</div>
				<div class="service-content">God Of WAR</p>		
				</div>
			</div>
		</div>

		<div class="services">
			<div class="ser-container">
			<div class="service-item">
				<div class="pic-size">
					<a href="assassins creed" target="_blank"><img src="img/m9.jpg" height="200px" width="200px"></a>
				</div>
				<div class="service-content">Assassins Creed</p>		
				</div>
			</div>
		</div>

		<div class="services">
			<div class="ser-container">
			<div class="service-item">
				<div class="pic-size">
					<a href="halo.php" target="_blank"><img src="img/m10.jpg" height="200px" width="200px"></a>
				</div>
				<div class="service-content">Halo</p>		
				</div>
			</div>
		</div>
		
		
	</section><br>
			
	<footer class="footer-part">
		<section id="Contacts"></section>
		<div class="footer-top">
			<div class="cont">Contacts:</div>
				<ul>
					<li><a href=""><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fb/Facebook_icon_2013.svg/2000px-Facebook_icon_2013.svg.png" width="30px" height="100%" alt=""></li>
					<li><a href=""><img src="https://cdn2.iconfinder.com/data/icons/minimalism/512/twitter.png" width="30px" height="100%" alt=""></li>
					<li><a href=""><img src="https://cdn0.iconfinder.com/data/icons/social-media-circle-6/1024/instagram-512.png" width="30px" height="100%" alt=""></li>
					<li><a href=""><img src="https://cdn1.iconfinder.com/data/icons/logotypes/32/square-linkedin-512.png" width="30px" height="100%" alt=""></li>
				
				</ul>
				<p>*Create a pool and Get result within 24 hours.</p>
				 <p>"The best Pooling system I've been to! And that's saying a lot, since I've been to many!"</p>
            <p>"Amazing system! Great service! Couldn't ask for more! I'll be back again and again!"</p>
			</div>
			<div class="footer-bottom"><hr>
				<p>© Copyright Online Polling System BD 2020</p>
			</div>
		</div>
	</footer>


</body>
</html>
<?php
  require_once "pdo.php";
  session_start();
  header("Content-Type: application/json; charset=utf-8");
  if(!isset($_SESSION['poll_id'])){
    die("ACCESS DENIED");
  }
  // $stmt = $pdo->query("SELECT * FROM poll JOIN choice ON poll.poll_id = choice.poll_id ORDER BY rank");
  // $rowspoll = $stmt->fetchAll(PDO::FETCH_ASSOC);
  // echo json_encode($rowspoll);
$commentNewCount = $_POST['commentNewCount'];
  $stmt = $pdo->prepare("SELECT * FROM poll WHERE status = 1 LIMIT = $commentNewCount");
  $stmt->execute(array(":poll_id" => $_POST['poll_id']));
  $data = array();
  while($rowspoll = $stmt->fetchAll(PDO::FETCH_ASSOC);){
    $data[] = $rowspoll;
  }
  echo json_encode($data);

  // $stmt = $pdo->query("SELECT payment.payment_id, user.email, payment.salary, payment.bonus,
  //                             payment.month,payment.payment_date
  //                               FROM payment JOIN user ON payment.user_id = user.user_id
  //                                ORDER BY payment_date DESC");
  // $rowt = $stmt->fetchAll(PDO::FETCH_ASSOC);


  // $stmt = $pdo->query("SELECT * FROM USER WHERE role = 0 AND paid_status = 0
  //                                 ORDER BY email");
  // $rowup = $stmt->fetchAll(PDO::FETCH_ASSOC);

 ?>

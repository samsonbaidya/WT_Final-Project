?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <title>RESET PASSWORD</title>
  <link rel="stylesheet" type="text/css" href="all.min.css">
 

    <link rel="stylesheet" type="text/css" href="reset.css">
     <body style="background-image: url(repass.jpg);  background-repeat: no-repeat; background-attachment: fixed;background-size: 100% 100%; ">
</head>
<body>
 <div class="container">
  <center><header class="rem">Online Polling System</header></center>
     <form method="POST" action="ultimate.php" id="form"> 
        <h1 class="neon">RECOVERY</h1>
  

        <div class="field">
            <i class="fa fa-envelope-o" aria-hidden="true"></i>
          <input onkeyup="check()" id="email" type="text" autocomplete="off" placeholder="Email">
          <div>
             <span class="icons" >
           <i id="danger" class="icon1">❌</i>
          <i id="right" class="icon2">✔️</i> 
          </span>
          </div></div>
     <div class="error-text">
Please Enter Valid Email Address</div>

        
        <div>
          <center>
           <div >
       <!--   <button class="btn" name="send">
       LOGIN</button> -->
             <a  href="recover.php" id="reg" class="btn">
              <span></span>
              <span></span>
              <span></span>
              <span></span>
             RECOVER
            </a>
          <a  href="login.php" id="reg">
              <span></span>
              <span></span>
              <span></span>
              <span></span>
             BACK
            </a></div>
          </center>
           
        </div>  
      </form>
</div>
<footer id="main-footer">
        <hr>
        <p>Copyright &copy; Online Polling System 2020  </p>
      </footer>

           <script type="text/javascript">
           
      const email = document.querySelector("#email");
      const icon1 = document.querySelector(".icon1");
      const icon2 = document.querySelector(".icon2");
      const error = document.querySelector(".error-text");
      const btn = document.querySelector(".btn");
      let regExp = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
      function check(){
        if(email.value.match(regExp)){
          // email.style.
          email.style.borderColor = "#18d635";
          // email.style.background = "#eafaf1";
          icon1.style.display = "none";
          icon2.style.display = "block";
          error.style.display = "none";
          btn.style.display = "block";
        }else{
          email.style.borderColor = "#f31701";
          // email.style.background = "#fceae9";
          icon1.style.display = "block";
          icon2.style.display = "none";
          error.style.display = "block";
          btn.style.display = "none";
        }
        if(email.value == ""){
          email.style.borderColor = "lightgrey";
          // email.style.background = "rgba(27, 25, 25, 0.9)";
          icon1.style.display = "none";
          icon2.style.display = "none";
          error.style.display = "none";
          btn.style.display = "none";
        }
      }
    </script>

             
                  
</body>
</html>
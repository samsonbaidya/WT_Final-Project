<?php
require_once "pdo.php";
require_once "util.php";
session_start();
if(isset($_POST['mainpage'])){
  header('Location:index.php');
  return;
}
if(isset($_SESSION['user_id'])){
    unset($_SESSION['user_id']);
}

if(isset($_POST['signup'])){
  if(isset($_POST['name']) && isset($_POST['email']) && isset($_POST['phone']) && isset($_POST['pw']) && isset($_POST['re-pw'])){

    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $salt = 'XyZzy12*_';
    $password = hash('md5', $salt.$_POST['pw']);

    $msg = signupValidation();
    if (is_string($msg)){
        $_SESSION["error"] = $msg;
        header("Location: signup.php");
        return;
    }
    try{
      $stmt = $pdo->prepare("SELECT * FROM user WHERE email = :email OR phone = :phone");
      $stmt->execute(array(":email" => $email,
                            ":phone" =>  $phone));
      $row = $stmt->fetch(PDO::FETCH_ASSOC);
      if($row !== false){
         $_SESSION["error"] = "Account already exist with this email or phone. Login to continue.";
         header("Location: login.php");
         return;
      }
      $sql = "INSERT INTO USER (name, email, password, phone)
                          VALUES (:name, :email, :pass, :phone)";
      $stmt = $pdo->prepare($sql);
      $stmt->execute(array(
          ':name' => $name,
          ':email' => $email,
          ':pass' => $password,
          ':phone' => $phone));
      $_SESSION["success"] = "Signup Successfully.";
      header("Location: index.php");
      return;
    }
    catch(Exception $ex){
      echo("Exception message: ". $ex->getMessage());
      header("Location: signup.php");
      return;
    }
  }else{
    $_SESSION['error'] = "Fillup all the field correctly.";
    header('Location: signup.php');
    return;
  }
}
 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>signup</title>
  </head>
  <body style="margin:20px;">
    <div class= "container">
      <form method="POST">

        <input type="submit" name="mainpage" value="<< Main Page"><br>

      </form>
      <h1> Sign UP</h1>

      <?php

        if ( isset($_SESSION["success"]) ) {
            echo('<p style="color:green">'.$_SESSION["success"]."</p>\n");
            unset($_SESSION["success"]);
        }
        else if ( isset($_SESSION["error"]) ) {
            echo('<p style="color:red">'.$_SESSION["error"]."</p>\n");
            unset($_SESSION["error"]);
        }
      ?>

      <form method="post">
        <table>
          <tr>
            <td>Name</td>
            <td> <input type="text" name="name" size=60> </td>
          </tr>
          <tr>
          <td>Email</td>
            <td> <input type="text" name="email" size=60> </td>
          </tr>
          <tr>
            <td>Phone</td>
              <td> <input type="text" name="phone"> </td>
            </tr>
          <tr>
          <tr>
            <td>Password</td>
              <td> <input type="password" name="pw"> </td>
            </tr>
          <tr>
          <tr>
            <td>Re-type Password</td>
              <td> <input type="password" name="re-pw"> </td>
            </tr>
          <tr>
            <td> <input type="submit" name="signup" value='Signup'> </td>
          </tr>
        </table>
      </form>

      <p><a href="login.php">Login</a> Or Goto <a href="index.php"> Main Page </a> </p>

    </div>
  </body>
</html>


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <title>OTP</title>
  <link rel="stylesheet" type="text/css" href="all.min.css">
 

    <link rel="stylesheet" type="text/css" href="OTP.css">
</head>
<body>
 <div class="container">
   <center><header class="rem">Online Polling System</header></center>
     <form method="POST" action="otp.php" id="form"> 
        <h1 class="neon">OTP</h1>

        <div class="textbox">
          <i class="fa fa-key fa-fw"></i>
          <input type="text"  placeholder="OTP-Code" id="myInput" name="pass" value="" required>    
          
          <span class="eye" onclick="myFunction()">
          <i id="hide1" class="fa fa-eye"></i> 
          <i id="hide2" class="fa fa-eye-slash"></i> 
          </span>
          <span id="text"></span>
        </div>   
        <br>&nbsp  
        <div>
          <center>
           <div >
         <button class="btn" name="send">
       ENTER</button>
        <a  href="login.php" id="reg">
              <span></span>
              <span></span>
              <span></span>
              <span></span>
             BACK
            </a>
            </div>
          </center>
           
        </div>  
        
      
     


      </form>
</div>
<footer id="main-footer">
        <hr>
        <p>Copyright &copy; Online Polling System 2020  </p>
      </footer>     
<script type="text/javascript">
            function myFunction(){
              var x =document.getElementById("myInput");
              var y =document.getElementById("hide1");
             var z = document.getElementById("hide2");
             if(x.type ==='password'){
              x.type="text";
              y.style.display = "block";
              z.style.display = "none";
             }
             else{
              x.type="password";
              y.style.display = "none";
              z.style.display = "block";
             }
            }
          </script>
          
             
                  
</body>
</html>
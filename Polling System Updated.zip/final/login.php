<?php
require_once "pdo.php";
session_start();
if(isset($_POST['mainpage'])){
  header("Location: index.php");
  return;
}
if(isset($_POST['signuppage'])){
  header("Location: signup.php");
  return;
}
if(isset($_SESSION['user_id'])){
    unset($_SESSION['user_id']);
}

if(isset($_POST['login'])){
  if (isset($_POST['email']) && isset($_POST['pass'])){
    unset($_SESSION['user_id']);
        if ( strlen($_POST['email']) < 1 || strlen($_POST['pass']) < 1 ) {
              $_SESSION["error"] = "Email and password are required";
              header("Location: login.php");
              return;
        } else {

            $pos = strpos($_POST['email'], '@');
            if($pos == 0){
                $_SESSION["error"] = "Email must have an at-sign (@)";
                header("Location: login.php");
                return;
            }
            $salt = 'XyZzy12*_';
            $check = hash('md5', $salt.$_POST['pass']);   //salted-hash protected pattern used
            try{
              $stmt = $pdo->prepare("SELECT * FROM user WHERE email = :email AND password = :password");
              $stmt->execute(array(":email" => $_POST['email'],
                                    ":password" => $check)
                                  );
              $row = $stmt->fetch(PDO::FETCH_ASSOC);
              $user_id = $row['user_id'];
              if($row===false){
                error_log("Login fail ".$_POST['email']." $check");
                $_SESSION["error"] = "Incorrect Email or Password";
                header("Location: login.php");
                return;
              }
              $_SESSION["user_id"] = $user_id;
              $_SESSION["success"] = "Logged in.";
              header("Location: home.php");
              error_log("Login success ".$_POST['email']);
              return;
            }
            catch(Exception $ex){
              echo("Exception message: ". $ex->getMessage());
              header("Location: login.php");
              return;
            }
        }
  }
}


 ?>


 <!DOCTYPE html>
 <html>
 <head>
 <title>Login</title>
 </head>
 <body style="margin:20px;">
 <div class="container">
   <form method="POST">
     <input type="submit" name="mainpage" value=" << Main Page "> <span style="margin-right:20px;"></span>
     <input type="submit" name="signuppage" value=" Signup Page >> "><br>
   </form>
 <h1>Please Log In</h1>
 <?php
     if ( isset($_SESSION["error"]) ) {
         echo('<p style="color:red">'.$_SESSION["error"]."</p>\n");
         unset($_SESSION["error"]);
     }
     if ( isset($_SESSION["success"]) ) {
         echo('<p style="color:green">'.$_SESSION["success"]."</p>\n");
         unset($_SESSION["success"]);
     }
 ?>
 <form method="POST">
 <label for="nam">Email</label>
 <input type="text" name="email" id="nam"><br/>
 <label for="id_1723">Password</label>
 <input type="password" name="pass" id="id_1723"><br/>
 <input type="submit" name= "login" value="Log In">
 <input type="hidden" name= "user_id" value="<?= $user_id ?>">
 <a href="recovery.php">Forgot Password?</a>
 </form>
 </div>
 </body>
 </html>

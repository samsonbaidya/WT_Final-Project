<?php
    require_once 'database.php';
    
    function getAllGame()
	{
		$query ="SELECT * FROM game_name ";
		$gme = get($query);
		return $gme;	
    }

    function getGame($id)
	{
		$query="SELECT * FROM game_name WHERE id='$id'";
		$gme=get($query);
		return $gme[0];
    }
    function updatevotecount($h_id, $count)
	{
		$query="UPDATE game_name SET count='$count' WHERE id='$h_id'";
		execute($query);
		
	}

    ?>
<?php
require_once "pdo.php";
require_once "util.php";
session_start();
if(!isset($_SESSION['user_id'])){
  $_SESSION['error'] = 'Login First';
  header('Location: login.php');
  return;
}

if(isset($_POST['Submit'])){
  if(isset($_POST['title']) && isset($_POST['desc'])){
      if(strlen($_POST['title'])<1 || strlen($_POST['desc'])<1){
        $_SESSION['error'] = "All fields are required";
        header("Location: createPoll.php");
        return;
      }
      for($i=1; $i<=9; $i++) {
        if ( ! isset($_POST['choice'.$i]) ) continue;
        $choice = $_POST['choice'.$i];
        if (strlen($choice) == 0) {
            $_SESSION['error'] =  "All fields are required";
            header('Location: managePoll.php');
            return;
        }
      }
      try{
        $sql = "INSERT INTO POLL (title, description, total_vote, status, user_id)
                                VALUES (:title, :description, :total_vote, :status, :user_id)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(array(
                ':user_id' => $_SESSION['user_id'],
                ':title' => $_POST['title'],
                ':description' => $_POST['desc'],
                ':total_vote' => 0,
                ':status' => 1
              ));
            $poll_id = $pdo->lastInsertId();
            $rank = 1;
            for($i=1; $i<=9; $i++) {
              if ( ! isset($_POST['choice'.$i]) ) continue;
              $choice_name = $_POST['choice'.$i];
              try {
                $stmt = $pdo->prepare('INSERT INTO CHOICE
                 (choice_name, rank, poll_id,total_vote)
                 VALUES ( :choice_name, :rank, :poll_id, 0)');
                 $stmt->execute(array(
                     ':poll_id' => $poll_id,
                     ':rank' => $rank,
                     ':choice_name' => $choice_name));

              } catch (Exception $ex) {
                echo("Exception message: ". $ex->getMessage());
                $_SESSION['error'] = "lol hahaha";
                header("Location: createPoll.php");
                return;
              }


              $rank++;
          }
            $_SESSION["success"] = "Poll Created Successfully";
            header("Location: home.php");
            return;
      }
      catch(Exception $ex){
        echo("Exception message: ". $ex->getMessage());
        $_SESSION['error'] = "lol";
        header("Location: createPoll.php");
        return;
      }
 }
}


 ?>

 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <title>Manage Poll</title>
     <!-- Bootstrap -->
     <link href="css/bootstrap.min.css" rel="stylesheet">
     <script src="https://kit.fontawesome.com/88b930df77.js" crossorigin="anonymous"></script>

     <style>
       .navbar{
         margin-bottom:0;
         border-radius:0;
       }
     </style>
   </head>
   <body>
     <header>
       <nav class="navbar navbar-inverse">
         <div class="container">
           <!-- Brand and toggle get grouped for better mobile display -->
           <div class="navbar-header">
             <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
               <span class="sr-only">Toggle navigation</span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
             </button>
              <a href="home.php" class="pull-left visible-md visible-lg">
                <div id="logo-img" alt="Logo image"></div>
              </a>
              <div class="navbar-brand">
                <a href="home.php"> <h1>Polling System</h1> </a>
                <p>
                  <i class="fas fa-lock"></i>
                  <span>SSL Certification</span>
                </p>
              </div>
           </div>

           <!-- Collect the nav links, forms, and other content for toggling -->
           <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
             <ul class="nav navbar-nav navbar-right" id="nav-list">
               <li class="active"><a href="home.php">Home<span class="sr-only">(current)</span></a></li>
               <li><a href="profile.php">Profile</a></li>
               <!-- <li><a href="createPoll.php">Create Poll</a></li> -->
               <li class="dropdown">
                 <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Manage Poll <span class="caret"></span></a>
                 <ul id="drop-list" class="dropdown-menu">
                   <li><a href="createPoll.php">Create Poll</a></li>
                   <li><a href="editPoll.php">Edit Poll</a></li>
                   <li><a href="deletePoll.php">Remove Poll</a></li>
                 </ul>


               <li><a href="result.php">Results</a></li>

               <!-- <li><a href="logout.php">Logout</a></li> -->
               <li class="dropdown">
                 <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Settings <span class="caret"></span></a>
                 <ul id="drop-list" class="dropdown-menu">
                   <li><a href="editProfile.php">Edit Profile</a></li>

                   <li><a href="deleteProfile.php">Delete Profile</a></li>

                   <li><a href="logout.php">Logout</a></li>
                 </ul>
               <!-- <li class="dropdown">
                 <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Result <span class="caret"></span></a>
                 <ul id="drop-list" class="dropdown-menu">
                   <li><a href="#">Publish</a></li>
                   <li><a href="#">Pending</a></li>
                   <li><a href="#">Top Results</a></li> -->
                   <!-- <li role="separator" class="divider"></li>
                   <li><a href="#">Separated link</a></li>
                   <li role="separator" class="divider"></li>
                   <li><a href="#">One more separated link</a></li> -->
                 </ul>
               </li>
             </ul>
           </div><!-- /.navbar-collapse -->
         </div><!-- /.container-fluid -->
       </nav>
     </header>
     <!-- HEADER ENDS -->
<hr>
    <!-- FORM CREATE POOL -->
     <div class="container">
       <div class="row">
         <div class="showInfo col-lg-12 col-md-12 col-sm-12 ">
           <h2>Create Poll</h2>
           <?php flashMessages(); ?>
          <form method="post">
            <div class="form-group">
              <label>Title</label>
              <input type="text" class="form-control" name="title" placeholder="Add Title">
            </div>
            <div class="form-group">
              <label>Description</label>
              <textarea class="form-control" name="desc" placeholder="Add Description"></textarea>
            </div>
            <div class="form-group">
              <p>
                Add Option: <input type="submit" id="addPos" value="+">
                <div id="position_fields">
                </div>
              </p>
            </div>
            <input type="submit" id="submitButton" name="Submit" value="Submit">
            </form>
            <hr>
        </div>
      </div>
     </div>

     <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
     <!-- Include all compiled plugins (below), or include individual files as needed -->
     <script src="js/bootstrap.min.js"></script>

     <script type="text/javascript">
       countPos = 0;
       $(document).ready(function(){
         window.console && console.log('Document ready called');
         $('#addPos').click(function(event){
           event.preventDefault();
           if(countPos >= 9){
             alert("Maximum of nine position entries exceeded");
             return;
           }
           countPos++;
           window.console && console.log("Adding position "+countPos);
           $('#position_fields').append(
             '<div id="position'+countPos+'"> \
                <p>Option'+countPos+': <input type="text" name="choice'+countPos+'" value="" /> \
                <input class="lessPos" type="button" value="-" \
                    onclick="$(\'#position'+countPos+'\').remove();return false;"></p> \
                </div>');
         });
     });
     </script>

     <!-- Fotter Starts -->
         <footer class="panel-footer">
           <div class="container">
             <div class="row">
               <section id="hours" class="col-sm-4">
                 <span>Hours:</span><br>
                 Open Service 24 hours<br>
                 <hr class="visible-xs">
               </section>
               <section id="address" class="col-sm-4">
                 <span>Address:</span><br>
                 American International University<br>
                 Kuratoli, Kuril, Bisswaroad.
                 <p>*Create a pool and Get result within 24 hours.</p>
                 <hr class="visible-xs">
               </section>
               <section id="testimonials" class="col-sm-4">
                 <p>"The best Pooling system I've been to! And that's saying a lot, since I've been to many!"</p>
                 <p>"Amazing system! Great service! Couldn't ask for more! I'll be back again and again!"</p>
               </section>
             </div>
             <div class="text-center">&copy; Copyright Pooling System BD 2020</div>
           </div>
         </footer>
         <!-- Footer ENDS -->

   </body>
 </html>

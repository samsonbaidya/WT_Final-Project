<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <title>User Signup Successful</title>
  <link rel="stylesheet" type="text/css" href="all.min.css">
  <body style="background-image: url(su1.jpg);  background-repeat: no-repeat; background-attachment: fixed;background-size: 100% 100%; ">
 

    <link rel="stylesheet" type="text/css" href="reg.css">
</head>
<body>  
<center>
 <div class="container">
 <h1 class="rem">Online Polling System</h1><br>
     <form method="POST" action="otp.php" id="form"> 
        <h3 class="neon"></h3>

       
         
         
    
           
           


<?php
    session_start();
    if(isset($_SESSION['fname']) && $_SESSION['lname'] && $_SESSION['uname'] && $_SESSION['gender']
       && $_SESSION['number'] && $_SESSION['address'] && $_SESSION['email'] && $_SESSION['age']) {
        echo "<b><i><u>Welcome ".$_SESSION['fname']." ".$_SESSION['lname']."</u><i></b><br></br>";
        echo "<b>You have been successfully registered in the system<b><br>";
        echo "<b>Your Username is: ".$_SESSION['uname']."</b><br>";
        echo "<b>Your Gender is: ".$_SESSION['gender']."</b><br>";
        echo "<b>Your Age is: ".$_SESSION['age']."</b><br>";
        echo "<b>Your Number is: ".$_SESSION['number']."</b><br>";
        echo "<b>Your Address is: ".$_SESSION['address']."</b><br>";
        echo "<b>Your Email is: ".$_SESSION['email']."</b>";
        #echo "Please logout and log back in.<br><br><br>";
        echo "<a href='homepage.html'>Go to the home page</a>";
    }
?>

 <a  href="login.php" id="user">
              <span></span>
              <span></span>
              <span></span>
              <span></span>
             GO TO THE LOGIN PAGE
            </a>

 </div>
          </center>
           
        </div>  
       
   </form>
  </fieldset>
  </div>
   
</center>
 <footer id="main-footer">
        <hr>
        <p>Copyright &copy; Online Polling System 2020  </p>
      </footer>
</body>
</center>
</html>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <title>Token Number for Signup</title>
  <link rel="stylesheet" type="text/css" href="all.min.css">
  <body style="background-image: url(key2.jpg);  background-repeat: no-repeat; background-attachment: fixed;background-size: 100% 100%; ">
 

    <link rel="stylesheet" type="text/css" href="reg.css">


</head>
<body> 
 
<center>
 <div class="container">
 <h1 class="rem">Online Polling System</h1><br>
    
        <h3 class="neon"></h3>

       
         
         
        
       

  <fieldset>



  <legend><h3><i>Token Number for Admin SignUp</i></h3></legend></br></br>
  <form method="post" action="permission.php">
    <p><b>Give the code which is provided for Admin Signup</b></p></br>
    <i class="fa fa-envelope" aria-hidden="true"></i>
          <input type="text" placeholder="Token Number"  name="permission" > <br><br>
       
  

 <?php 
  if (isset($_POST['submit'])) {
    $check = $_POST['permission'];
    if ($check ==246 ){ //token=1234
      header("location: adminsignup.php");
    }
    else {
      echo "<i>Permission code doesn't match</i> <br><br><br>";
    }
  }
  elseif(isset($_POST['cancel'])) 
  {
    header("location: login.php");
  }
  ?>
  <?php
      setcookie('identifier', 'permission', time()+60);
  ?>

       <input style="background-color:gray" class="neon2" type="submit" name="cancel" value="Back">&nbsp &nbsp &nbsp
       <input style="background-color:green" class="neon1" type="submit" name="submit" value="Check">
   </form>
  </fieldset>
  </div>

   
</center>
 <footer id="main-footer">
        <hr>
        <p>Copyright &copy; Online Polling System 2020  </p>
      </footer>
</body>
</html>
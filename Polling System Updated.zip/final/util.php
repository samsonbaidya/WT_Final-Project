<?php
require_once "pdo.php";
//flash messages
function flashMessages(){
  if ( isset($_SESSION["success"]) ) {
      echo('<p class="text-success">'.$_SESSION["success"]."</p>\n");
      unset($_SESSION["success"]);
  }
  else if ( isset($_SESSION["error"]) ) {
      echo('<p class="text-danger">'.$_SESSION["error"]."</p>\n");
      unset($_SESSION["error"]);
  }
}
//SIGNUP VALIDATION
function signupValidation(){
  if(strlen($_POST['name'])<1 || strlen($_POST['email'])<1 || strlen($_POST['phone'])<1 || strlen($_POST['pw'])<1 || strlen($_POST['re-pw'])<1){
      return "All fields are required.";
  }
  $pos = strpos($_POST['email'], '@');
  if($pos == 0){
    return "Email must have an at-sign (@)";
  }
  if(!is_numeric($_POST['phone'])){
    $_SESSION["error"] = "Phone number must be a number.";
    header("Location: signup.php");
    return;
  }
  if($_POST['pw'] != $_POST['re-pw']){
    $_SESSION["error"] = "Password must be matched.";
    header("Location: signup.php");
    return;
  }
  return true;
}



?>

<?php
require_once "pdo.php";
require_once "util.php";
session_start();
if(!isset($_SESSION['user_id'])){
  die("ACCESS DENIED");
}
if(isset($_POST['Delete'])){
  if(!isset($_POST['pass']) || strlen($_POST['pass']) < 1){
    $_SESSION["error"] = "You must type your password to delete your account";
    header('Location: deleteProfile.php');
    return;
  }
  try{
    $stmt = $pdo->prepare("SELECT * FROM user WHERE user_id = :user_id");
    $stmt->execute(array(":user_id" => $_SESSION['user_id']));
    $rowsuser = $stmt->fetch(PDO::FETCH_ASSOC);
    if($rowsuser["password"] !== $_POST['pass']){
      $_SESSION["error"] = "Type your password correctly to delete your account";
      header('Location: deleteProfile.php');
      return;
    }

    $stmt = $pdo->prepare("DELETE FROM user WHERE user_id = :user_id");
    $stmt->execute(array(":user_id" => $_SESSION['user_id']));
    $_SESSION["success"] = "Account Deleted Successfully";
    header('Location: logout.php');
    return;
  }
  catch(Exception $ex){
    $_SESSION['error'] = "exception occured";
    header('Location:deleteProfile.php');
    return;
  }

}

$stmt = $pdo->prepare("SELECT * FROM user WHERE user_id = :user_id");
$stmt->execute(array(":user_id" => $_SESSION['user_id']));
$rowsuser = $stmt->fetch(PDO::FETCH_ASSOC);
 ?>

<!DOCTYPE html>
<html lang="en">
 <head>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>Home</title>
   <!-- Bootstrap -->
   <link rel="stylesheet"
   href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"
   integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7"
   crossorigin="anonymous">

   <link rel="stylesheet"
   href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css"
   integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r"
   crossorigin="anonymous">

   <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/ui-lightness/jquery-ui.css">

   <script src="https://code.jquery.com/jquery-3.2.1.js"
   integrity="sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE="
   crossorigin="anonymous"></script>

   <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"
   integrity="sha256-T0Vest3yCU7pafRw9r+settMBX6JkKN06dqBnpQ8d30="
   crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/88b930df77.js" crossorigin="anonymous"></script>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

   <script src="https://kit.fontawesome.com/88b930df77.js" crossorigin="anonymous"></script>

   <style>
     .navbar{
       margin-bottom:0;
       border-radius:0;
     }
   </style>
 </head>
 <body>
   <nav class="navbar navbar-inverse">
     <div class="container">
       <!-- Brand and toggle get grouped for better mobile display -->
       <div class="navbar-header">
         <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
           <span class="sr-only">Toggle navigation</span>
           <span class="icon-bar"></span>
           <span class="icon-bar"></span>
           <span class="icon-bar"></span>
         </button>
          <a href="home.php" class="pull-left visible-md visible-lg">
            <div id="logo-img" alt="Logo image"></div>
          </a>
          <div class="navbar-brand">
            <a href="home.php"> <h1>Polling System</h1> </a>
            <p>
              <i class="fas fa-lock"></i>
              <span>SSL Certification</span>
            </p>
          </div>
       </div>

       <!-- Collect the nav links, forms, and other content for toggling -->
       <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
         <ul class="nav navbar-nav navbar-right" id="nav-list">
           <li class="active"><a href="home.php">Home<span class="sr-only">(current)</span></a></li>
           <li><a href="profile.php">Profile</a></li>
           <!-- <li><a href="managePoll.php">Create Poll</a></li> -->
           <li class="dropdown">
             <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Manage Poll <span class="caret"></span></a>
             <ul id="drop-list" class="dropdown-menu">
               <li><a href="createPoll.php">Create Poll</a></li>
               <li><a href="editPoll.php">Edit Poll</a></li>
               <li><a href="deletePoll.php">Remove Poll</a></li>
             </ul>


           <li><a href="result.php">Results</a></li>

           <!-- <li><a href="logout.php">Logout</a></li> -->
           <li class="dropdown">
             <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Settings <span class="caret"></span></a>
             <ul id="drop-list" class="dropdown-menu">
               <li><a href="editProfile.php">Edit Profile</a></li>

               <li><a href="deleteProfile.php">Delete Profile</a></li>

               <li><a href="logout.php">Logout</a></li>
             </ul>
           <!-- <li class="dropdown">
             <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Result <span class="caret"></span></a>
             <ul id="drop-list" class="dropdown-menu">
               <li><a href="#">Publish</a></li>
               <li><a href="#">Pending</a></li>
               <li><a href="#">Top Results</a></li> -->
               <!-- <li role="separator" class="divider"></li>
               <li><a href="#">Separated link</a></li>
               <li role="separator" class="divider"></li>
               <li><a href="#">One more separated link</a></li> -->
             </ul>
           </li>
         </ul>
       </div><!-- /.navbar-collapse -->
     </div><!-- /.container-fluid -->
   </nav>

<hr>

  <div class="container">
    <div class="row">

      <div class="showInfo col-lg-12 col-md-12 col-sm-12">
       <form method="post">
        <?php flashMessages(); ?>
        <?php

            echo '<h2>General Information</h2> <p class="name"> <label>Name:</label> <input type="text" value="';
            echo(htmlentities($rowsuser['name']));
            echo '" readonly></p>';
            echo '<p class="email"> <label>Email:</label> <input type="text" value="';
            echo(htmlentities($rowsuser['email']));
            echo '" readonly></p>';
            echo '<p class="phone"> <label>Phone:</label> <input type="text" value="';
            echo(htmlentities($rowsuser['phone']));
            echo '" readonly></p>';
         ?><br>

           <p>
           <label>Password</label>
           <input type="password" name="pass" placeholder="Enter your Password">
          </p>

           <input type="submit" id="submitButton" name"Delete" value="Delete">
         </form>
         <br>
      </div>

    </div>
  </div>

  <hr>

  <script src="js/bootstrap.min.js"></script>


<!-- Fotter Starts -->
   <footer class="panel-footer">
     <div class="container">
       <div class="row">
         <section id="hours" class="col-sm-4">
           <span>Hours:</span><br>
           Open Service 24 hours<br>
           <hr class="visible-xs">
         </section>
         <section id="address" class="col-sm-4">
           <span>Address:</span><br>
           American International University<br>
           Kuratoli, Kuril, Bisswaroad.
           <p>*Create a pool and Get result within 24 hours.</p>
           <hr class="visible-xs">
         </section>
         <section id="testimonials" class="col-sm-4">
           <p>"The best Pooling system I've been to! And that's saying a lot, since I've been to many!"</p>
           <p>"Amazing system! Great service! Couldn't ask for more! I'll be back again and again!"</p>
         </section>
       </div>
       <div class="text-center">&copy; Copyright Pooling System BD 2020</div>
     </div>
   </footer>
   <!-- Footer ENDS -->



 </body>
</html>

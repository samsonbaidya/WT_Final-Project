<?php
require_once "pdo.php";
require_once "util.php";
session_start();
if(!isset($_GET['poll_id'])){
  die("ACCESS DENIED");
}
$_SESSION['poll_id'] = $_GET['poll_id'];

if(isset($_POST['select'])){
  if (!isset($_POST['choice'])){
    $_SESSION['error'] = "You must vote atleast one option";
    header('Location:vote.php?poll_id='.$_SESSION['poll_id']);
    return;
  }
  try{
    $stmt = $pdo->prepare("SELECT * FROM VOTE WHERE user_id = :user_id AND choice_id = :choice_id");
    $stmt->execute(array(":user_id" => $_SESSION['user_id'],
                          ":choice_id" =>  $_POST['choice']));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if($row !== false){
       $_SESSION["error"] = "You cannot vote multiple times in same choice.you may select another option";
       header("Location:vote.php?poll_id=".$_SESSION['poll_id']);
       return;
    }

    $stmt = $pdo->prepare("INSERT INTO VOTE(user_id, choice_id)
                                    VALUES(:user_id, :choice_id) ");
    $stmt->execute(array(
        ':user_id' => $_SESSION['user_id'],
        ':choice_id' => $_POST['choice']
      ));

      $stmt = $pdo->prepare("SELECT * FROM POLL WHERE poll_id = :poll_id");
      $stmt->execute(array(":poll_id" => $_SESSION['poll_id']));
      $row = $stmt->fetch(PDO::FETCH_ASSOC);

      $sql = "UPDATE poll SET total_vote = :total_vote WHERE poll_id = :poll_id";
      $stmt = $pdo->prepare($sql);
      $stmt->execute(array(
          ':total_vote' => $row['total_vote']+1,
          ':poll_id' =>  $_SESSION['poll_id']));

      $stmt = $pdo->prepare("SELECT * FROM CHOICE WHERE choice_id = :choice_id");
      $stmt->execute(array(":choice_id" =>  $_POST['choice']));
      $row = $stmt->fetch(PDO::FETCH_ASSOC);

      $sql = "UPDATE CHOICE SET total_vote = :total_vote WHERE choice_id = :choice_id";
      $stmt = $pdo->prepare($sql);
      $stmt->execute(array(":choice_id" =>  $_POST['choice'],
                            ":total_vote" => $row['total_vote']+1));

    $_SESSION["success"] = "Your vote is successfull.";
    header("Location: home.php");
    return;
  }catch(Exception $ex){
    echo("Exception message: ". $ex->getMessage());
    $_SESSION['error'] = "lol";
    header("Location: home.php");
    return;
  }

}

$stmt = $pdo->prepare("SELECT * FROM poll WHERE poll_id = :poll_id");
$stmt->execute(array(":poll_id" => $_SESSION['poll_id']));
$rowspoll = $stmt->fetch(PDO::FETCH_ASSOC);


$stmt = $pdo->prepare("SELECT * FROM choice WHERE poll_id = :poll_id ORDER BY rank ");
$stmt->execute(array(":poll_id" => $_SESSION['poll_id']));
$options = array();
while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
  $options[] = $row;
}


 ?>
 <!DOCTYPE html>
 <html lang="en">
   <head>
     <meta charset="utf-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <title>Home</title>
     <!-- Bootstrap -->
     <link href="css/bootstrap.min.css" rel="stylesheet">
     <script src="https://kit.fontawesome.com/88b930df77.js" crossorigin="anonymous"></script>

     <style>
       .navbar{
         margin-bottom:0;
         border-radius:0;
       }
     </style>
   </head>
   <body>
     <nav class="navbar navbar-inverse">
       <div class="container">
         <!-- Brand and toggle get grouped for better mobile display -->
         <div class="navbar-header">
           <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
             <span class="sr-only">Toggle navigation</span>
             <span class="icon-bar"></span>
             <span class="icon-bar"></span>
             <span class="icon-bar"></span>
           </button>
            <a href="home.php" class="pull-left visible-md visible-lg">
              <div id="logo-img" alt="Logo image"></div>
            </a>
            <div class="navbar-brand">
              <a href="home.php"> <h1>Polling System</h1> </a>
              <p>
                <i class="fas fa-lock"></i>
                <span>SSL Certification</span>
              </p>
            </div>
         </div>

         <!-- Collect the nav links, forms, and other content for toggling -->
         <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
           <ul class="nav navbar-nav navbar-right" id="nav-list">
             <li class="active"><a href="home.php">Home<span class="sr-only">(current)</span></a></li>
             <li><a href="profile.php">Profile</a></li>
             <!-- <li><a href="managePoll.php">Create Poll</a></li> -->
             <li class="dropdown">
               <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Manage Poll <span class="caret"></span></a>
               <ul id="drop-list" class="dropdown-menu">
                 <li><a href="createPoll.php">Create Poll</a></li>
                 <li><a href="editPoll.php">Edit Poll</a></li>
                 <li><a href="deletePoll.php">Remove Poll</a></li>
               </ul>


             <li><a href="result.php">Results</a></li>

             <!-- <li><a href="logout.php">Logout</a></li> -->
             <li class="dropdown">
               <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Settings <span class="caret"></span></a>
               <ul id="drop-list" class="dropdown-menu">
                 <li><a href="editProfile.php">Edit Profile</a></li>

                 <li><a href="deleteProfile.php">Delete Profile</a></li>

                 <li><a href="logout.php">Logout</a></li>
               </ul>
             <!-- <li class="dropdown">
               <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Result <span class="caret"></span></a>
               <ul id="drop-list" class="dropdown-menu">
                 <li><a href="#">Publish</a></li>
                 <li><a href="#">Pending</a></li>
                 <li><a href="#">Top Results</a></li> -->
                 <!-- <li role="separator" class="divider"></li>
                 <li><a href="#">Separated link</a></li>
                 <li role="separator" class="divider"></li>
                 <li><a href="#">One more separated link</a></li> -->
               </ul>
             </li>
           </ul>
         </div><!-- /.navbar-collapse -->
       </div><!-- /.container-fluid -->
     </nav>

<hr>
     <div class="container">
     <div id="cat" class="cat row">
       <form method="post">
         <?php
             echo '<div class="showme col-lg-12 col-md-12 col-sm-12"><p class="title">Title </p> <p class="title">';
             echo(htmlentities($rowspoll['title']));
             echo "</p>";
             echo "<p class='desc'>Description </p> <p class='desc'>";
             echo(htmlentities($rowspoll['description']));
             echo "</p>";
             echo "<p class='total_vote'>Total Vote </p>  <p class='total_vote'>";
             echo(htmlentities($rowspoll['total_vote']));
             echo "</p>";
             echo "<p id='choicePanel' class='choicePanel'>";
            $pos=0;
                                  flashMessages();
               foreach ($options as $position) {
                 // if($position["poll_id"] != $row['poll_id']) continue;
                 $pos++;
                 echo '<div id="choice'.$pos.'">';
                 echo '<ul><li><input type="radio" name="choice" value="'.htmlentities($position["choice_id"]).'"> &nbsp;'.htmlentities($position["choice_name"]).':'.htmlentities($position["total_vote"]).'</li></ul></div>';
               }
               echo '</p>';
               echo '<input type="submit" id="vote_now" name="select" value="Confirm Vote"><br><br>
               </div></a><div class"clearfix visible-lg-block"></div><hr class="visible-xs">';
         ?>
       </form>

          </div>
       </div>

     <hr>


    <!-- <script>
      // $(document).ready(function(){
      //   $.getJSON('pollJSON.php', function(data){
      //     windows.console $$ console.log(data);
      //     $(showme)
      //   })
      // });

            var req = new XMLHttpRequest();
            req.open('GET', 'pollJSON.php', true);
            req.onload = function() {
                if(req.status==200){
                  var poll = JSON.parse(req.responseText)
                  windows.console && console.log(poll);
                  var display='';
                  for(var i in poll){
                   display += '<div class="col-lg-3 col-md-4 col-md-sm-6">'+
                           '<ul">'+
                             '<li>Content Title'+i.title+'</li>'+
                             '<li>Description'+i.description+'</li>'+
                             '<li>Total Vote'+i.total_vote+'</li>'+
                             // '<li>Choice'+poll.choice_name+'</li>'+
                           '</ul>'+
                         '</div>';
                   document.getElementById('showme').innerHTML = display;
                   }

                }

            }
            req.send();
        })
    </script> -->



 <!-- Fotter Starts -->
     <footer class="panel-footer">
       <div class="container">
         <div class="row">
           <section id="hours" class="col-sm-4">
             <span>Hours:</span><br>
             Open Service 24 hours<br>
             <hr class="visible-xs">
           </section>
           <section id="address" class="col-sm-4">
             <span>Address:</span><br>
             American International University<br>
             Kuratoli, Kuril, Bisswaroad.
             <p>*Create a pool and Get result within 24 hours.</p>
             <hr class="visible-xs">
           </section>
           <section id="testimonials" class="col-sm-4">
             <p>"The best Pooling system I've been to! And that's saying a lot, since I've been to many!"</p>
             <p>"Amazing system! Great service! Couldn't ask for more! I'll be back again and again!"</p>
           </section>
         </div>
         <div class="text-center">&copy; Copyright Pooling System BD 2020</div>
       </div>
     </footer>
     <!-- Footer ENDS -->


     <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
     <!-- Include all compiled plugins (below), or include individual files as needed -->
     <script src="js/bootstrap.min.js"></script>

   </body>
 </html>

<?php
// Array with names
$a[] = "Ani";
$a[] = "Bithi";
$a[] = "Cind";
$a[] = "Dina";
$a[] = "Eva";
$a[] = "Fiona";
$a[] = "Godhu";
$a[] = "Himel";
$a[] = "Ishika";
$a[] = "Jannat";
$a[] = "Kiara";
$a[] = "Liona";
$a[] = "Noor";
$a[] = "Orpa";
$a[] = "Priyasha";
$a[] = "Primi";
$a[] = "Rizwa";
$a[] = "Snata";
$a[] = "Safa";
$a[] = "Prapti";
$a[] = "Manha";
$a[] = "Sumaiya";
$a[] = "Tuba";
$a[] = "Urvashi";
$a[] = "Vigo";
$a[] = "Lucky";
$a[] = "Eshita";
$a[] = "Woishe";
$a[] = "Oishe";
$a[] = "Methila";

// get the q parameter from URL
$q = $_REQUEST["q"];

$hint = "";

// lookup all hints from array if $q is different from ""
if ($q !== "") {
  $q = strtolower($q);
  $len=strlen($q);
  foreach($a as $name) {
    if (stristr($q, substr($name, 0, $len))) {
      if ($hint === "") {
        $hint = $name;
      } else {
        $hint .= ", $name";
      }
    }
  }
}

// Output "no suggestion" if no hint was found or output correct values
echo $hint === "" ? "no suggestion" : $hint;
?>
<?php 
     require_once ('Votecontrol.php');  
      

  
      
    
     if(isset($_POST['submit']))
     {

      
        $game_id=$_GET["id"]; 
        
        
        
        
        $game=getGame($game_id);

        $vcount=$game["count"];
        

        (int)$vcount=(int)$vcount + 1;

        
      

        updatevotecount($game_id,$vcount);
        header("Location:homepage.php");
     }
        
       
    
    
?>
<html>
    <head>
        <title>Voting</title>
        
        <style>
            
        </style>
    </head>
    <body>
        <form action="" method="post">

        
            <input type="submit" name="submit" value="OK" style="width:150">
                      

        </form>
        
    </body>
</html>
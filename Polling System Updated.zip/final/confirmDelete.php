<?php
require_once "pdo.php";
require_once "util.php";
session_start();
if(!isset($_GET['poll_id'])){
  die("ACCESS DENIED");
}
$_SESSION['poll_id'] = $_GET['poll_id'];

if(isset($_POST['delete'])){
      try{
        $stmt = $pdo->prepare('DELETE FROM choice WHERE poll_id=:poll_id');
        $stmt->execute(array( ':poll_id' => $_SESSION['poll_id']));

        $stmt = $pdo->prepare('DELETE FROM poll WHERE poll_id=:poll_id');
        $stmt->execute(array( ':poll_id' => $_SESSION['poll_id']));

        $_SESSION['success'] = "Poll Deletd Successfully";
        header("Location:home.php");
        return;
      }
      catch(Exception $ex){
        echo("Exception message: ". $ex->getMessage());
        $_SESSION['error'] = "lol";
        header("Location: confirmEdit.php");
        return;
      }

}


$stmt = $pdo->prepare("SELECT * FROM poll WHERE poll_id = :poll_id");
$stmt->execute(array(":poll_id" => $_GET['poll_id']));
$rowspoll = $stmt->fetch(PDO::FETCH_ASSOC);
$pollTitle = htmlentities($rowspoll['title']);
$pollDesc = htmlentities($rowspoll['description']);

$stmt = $pdo->prepare("SELECT * FROM choice WHERE poll_id = :poll_id ORDER BY rank ");
$stmt->execute(array(":poll_id" => $_SESSION['poll_id']));
$options = array();
while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
  $options[] = $row;
}


 ?>
 <!DOCTYPE html>
 <html lang="en">
   <head>
     <meta charset="utf-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <title>Home</title>

     <link rel="stylesheet"
     href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"
     integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7"
     crossorigin="anonymous">

     <link rel="stylesheet"
     href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css"
     integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r"
     crossorigin="anonymous">

     <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/ui-lightness/jquery-ui.css">

     <script src="https://code.jquery.com/jquery-3.2.1.js"
     integrity="sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE="
     crossorigin="anonymous"></script>

     <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"
     integrity="sha256-T0Vest3yCU7pafRw9r+settMBX6JkKN06dqBnpQ8d30="
     crossorigin="anonymous"></script>
      <script src="https://kit.fontawesome.com/88b930df77.js" crossorigin="anonymous"></script>
      <!-- Bootstrap -->
      <link href="css/bootstrap.min.css" rel="stylesheet">
     <style>
       .navbar{
         margin-bottom:0;
         border-radius:0;
       }
     </style>
   </head>
   <body>
     <nav class="navbar navbar-inverse">
       <div class="container">
         <!-- Brand and toggle get grouped for better mobile display -->
         <div class="navbar-header">
           <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
             <span class="sr-only">Toggle navigation</span>
             <span class="icon-bar"></span>
             <span class="icon-bar"></span>
             <span class="icon-bar"></span>
           </button>
            <a href="home.php" class="pull-left visible-md visible-lg">
              <div id="logo-img" alt="Logo image"></div>
            </a>
            <div class="navbar-brand">
              <a href="home.php"> <h1>Polling System</h1> </a>
              <p>
                <i class="fas fa-lock"></i>
                <span>SSL Certification</span>
              </p>
            </div>
         </div>

         <!-- Collect the nav links, forms, and other content for toggling -->
         <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
           <ul class="nav navbar-nav navbar-right" id="nav-list">
             <li class="active"><a href="home.php">Home<span class="sr-only">(current)</span></a></li>
             <li><a href="profile.php">Profile</a></li>
             <!-- <li><a href="managePoll.php">Create Poll</a></li> -->
             <li class="dropdown">
               <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Manage Poll <span class="caret"></span></a>
               <ul id="drop-list" class="dropdown-menu">
                 <li><a href="createPoll.php">Create Poll</a></li>
                 <li><a href="editPoll.php">Edit Poll</a></li>
                 <li><a href="deletePoll.php">Remove Poll</a></li>
               </ul>


             <li><a href="result.php">Results</a></li>

             <!-- <li><a href="logout.php">Logout</a></li> -->
             <li class="dropdown">
               <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Settings <span class="caret"></span></a>
               <ul id="drop-list" class="dropdown-menu">
                 <li><a href="editProfile.php">Edit Profile</a></li>

                 <li><a href="deleteProfile.php">Delete Profile</a></li>

                 <li><a href="logout.php">Logout</a></li>
               </ul>
             <!-- <li class="dropdown">
               <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Result <span class="caret"></span></a>
               <ul id="drop-list" class="dropdown-menu">
                 <li><a href="#">Publish</a></li>
                 <li><a href="#">Pending</a></li>
                 <li><a href="#">Top Results</a></li> -->
                 <!-- <li role="separator" class="divider"></li>
                 <li><a href="#">Separated link</a></li>
                 <li role="separator" class="divider"></li>
                 <li><a href="#">One more separated link</a></li> -->
               </ul>
             </li>
           </ul>
         </div><!-- /.navbar-collapse -->
       </div><!-- /.container-fluid -->
     </nav>

<hr>

<!-- FORM CREATE POOL -->
 <div class="container">
   <div class="row">
     <div class="showInfo col-lg-12 col-md-12 col-sm-12 ">
       <h2>Delete Poll</h2>
       <?php flashMessages(); ?>
      <form method="post">
        <div class="form-group">
          <label>Title</label>
          <input type="text" class="form-control" name="title" value="<?= $pollTitle  ?>" readonly>
        </div>
        <div class="form-group">
          <label>Description</label>
          <textarea class="form-control" name="desc" readonly><?= $pollDesc ?></textarea>
        </div>
        <div id="position_fields">
          <?php
          $pos=0;
            foreach ($options as $position) {
              $pos++;
              echo '<div id="position'.$pos.'">';
              echo '<p>Choice'.$pos.': <input type="text" name="choice_name'.$pos.'" value="'.$position["choice_name"].'" readonly> </p>
              </div>';
            }
           ?>
           </div>

        <input type="submit" id="submitButton" name="delete" value="Confirm Delete">
        </form>
        <hr>
    </div>
  </div>
 </div>

<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js/bootstrap.min.js"></script>


  <script src="js/jquery-1.10.2.js"></script>
  <script src="js/jquery-ui-1.11.4.js"></script>

<script>

// http://stackoverflow.com/questions/17650776/add-remove-html-inside-div-using-javascript
$(document).ready(function(){
        alert('All your records will be deleted.');

});
</script>

<!--
<script>
  // $(document).ready(function(){
  //   $.getJSON('pollJSON.php', function(data){
  //     windows.console $$ console.log(data);
  //   })
  // });
        var req = new XMLHttpRequest();
        req.open('GET', 'pollJSON.php', true);
        req.onload = function() {
            if(req.status==200){
              var poll = JSON.parse(req.responseText)
              var display='';
              for(var i in people){
               display += '<a href="showprofile.php?poll_id='++'"><div class="col-lg-3 col-md-4 col-md-sm-6">'+
                       '<ul">'+
                         '<li>Content Title'+poll.title+'</li>'+
                         '<li>Description'+poll.description+'</li>'+
                         '<li>Total Vote'+poll.total_vote+'</li>'+
                         '<li>Choice'+poll.choice_name+'</li>'+
                       '</ul>'+
                     '</div></a>';
               document.getElementById('showme').innerHTML = display;
               }

            }

        }
        req.send();

</script>
 -->


     <hr>


    <!-- <script>
      // $(document).ready(function(){
      //   $.getJSON('pollJSON.php', function(data){
      //     windows.console $$ console.log(data);
      //     $(showme)
      //   })
      // });

            var req = new XMLHttpRequest();
            req.open('GET', 'pollJSON.php', true);
            req.onload = function() {
                if(req.status==200){
                  var poll = JSON.parse(req.responseText)
                  windows.console && console.log(poll);
                  var display='';
                  for(var i in poll){
                   display += '<div class="col-lg-3 col-md-4 col-md-sm-6">'+
                           '<ul">'+
                             '<li>Content Title'+i.title+'</li>'+
                             '<li>Description'+i.description+'</li>'+
                             '<li>Total Vote'+i.total_vote+'</li>'+
                             // '<li>Choice'+poll.choice_name+'</li>'+
                           '</ul>'+
                         '</div>';
                   document.getElementById('showme').innerHTML = display;
                   }

                }

            }
            req.send();
        })
    </script> -->



 <!-- Fotter Starts -->
     <footer class="panel-footer">
       <div class="container">
         <div class="row">
           <section id="hours" class="col-sm-4">
             <span>Hours:</span><br>
             Open Service 24 hours<br>
             <hr class="visible-xs">
           </section>
           <section id="address" class="col-sm-4">
             <span>Address:</span><br>
             American International University<br>
             Kuratoli, Kuril, Bisswaroad.
             <p>*Create a pool and Get result within 24 hours.</p>
             <hr class="visible-xs">
           </section>
           <section id="testimonials" class="col-sm-4">
             <p>"The best Pooling system I've been to! And that's saying a lot, since I've been to many!"</p>
             <p>"Amazing system! Great service! Couldn't ask for more! I'll be back again and again!"</p>
           </section>
         </div>
         <div class="text-center">&copy; Copyright Pooling System BD 2020</div>
       </div>
     </footer>
     <!-- Footer ENDS -->




   </body>
 </html>

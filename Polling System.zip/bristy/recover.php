
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
	<title>RECOVERY</title>
  <link rel="stylesheet" type="text/css" href="all.min.css">
 

	<link rel="stylesheet" type="text/css" href="recover.css">
 <body style="background-image: url(recover.jpg);  background-repeat: no-repeat; background-attachment: fixed;background-size: 100% 100%; ">
</head>
<body>
 <div class="container">
  <center><header class="rem">Online Polling System</header></center>
 	 <form method="POST"  id="form"> 
        <h1 class="neon">RECOVERY</h1>
  
<!-- email -->
        <div class="email">
        	<i class="fa fa-envelope-o" aria-hidden="true"></i>
          <input onkeyup="check()" id="email" type="text" autocomplete="off" placeholder="Email"></div>
      <div style="float: right;position: relative;top:-35px">
             <span class="icons" >
           <i id="danger" class="icon1">❌</i>
          <i id="right" class="icon2">✔️</i> 
          </span>
          </div>
     <div class="error-text">
Please Enter Valid Email Address</div>
<!-- OTP -->
 <div class="textbox">

          <i class="fa fa-key fa-fw"></i>
          <input type="password"  placeholder="OTP-Code" id="myInput" name="pass" value="" required>    
          
          <span class="eye" onclick="myFunction()">
          <i id="hide1" class="fa fa-eye"></i> 
          <i id="hide2" class="fa fa-eye-slash"></i> 
          </span>
          <span id="text"></span>
        </div>   

        <div class="textbox">
          <i class="fa fa-key fa-fw"></i>
          <input type="password"  placeholder="Password" id="put" name="pass" value="" required>    
          
          <span class="ceye" onclick="myCFunction()">
          <i id="hide3" class="fa fa-eye"></i> 
          <i id="hide4" class="fa fa-eye-slash"></i> 
          </span>
          <span id="text"></span>
        </div>   
        <br>&nbsp  
       
         <div><center>
           <i id="fpass" >  Generate a strong password? </i></center><a  href="passval.php" class="reset">
              <span></span>
              <span></span>
              <span></span>
              <span></span>
            Click Here!!!
            </a> 
        </div>

       
          <center>
           <div >
         <div >
        <a  href="welcome.html" id="reg">
              <span></span>
              <span></span>
              <span></span>
              <span></span>
             ENTER
            </a>
            </div><div> 
             <a  href="login.html" id="reg">
              <span></span>
              <span></span>
              <span></span>
              <span></span>
             BACK
            </a></div>
          </center>
           
                
      
     


      </form>
</div>
<footer id="main-footer">
        <hr>
        <p>Copyright &copy; Online Polling System 2020  </p>
      </footer>  
<script type="text/javascript">
            function myFunction(){
              var x =document.getElementById("myInput");
              var y =document.getElementById("hide1");
             var z = document.getElementById("hide2");
             if(x.type ==='password'){
              x.type="text";
              y.style.display = "block";
              z.style.display = "none";
             }
             else{
              x.type="password";
              y.style.display = "none";
              z.style.display = "block";
             }
            }
          </script>
          <script type="text/javascript">
            function myCFunction(){
              var a =document.getElementById("put");
              var b =document.getElementById("hide3");
             var c = document.getElementById("hide4");
             if(a.type ==='password'){
              a.type="text";
              b.style.display = "block";
              c.style.display = "none";
             }
             else{
              a.type="password";
              b.style.display = "none";
              c.style.display = "block";
             }
            }
          </script>
           <script type="text/javascript">
           
      const email = document.querySelector("#email");
      const icon1 = document.querySelector(".icon1");
      const icon2 = document.querySelector(".icon2");
      const error = document.querySelector(".error-text");
      const btn = document.querySelector(".btn");
      let regExp = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
      function check(){
        if(email.value.match(regExp)){
          // email.style.
          email.style.borderColor = "#18d635";
          // email.style.background = "#eafaf1";
          icon1.style.display = "none";
          icon2.style.display = "block";
          error.style.display = "none";
          btn.style.display = "block";
        }else{
          email.style.borderColor = "#f31701";
          // email.style.background = "#fceae9";
          icon1.style.display = "block";
          icon2.style.display = "none";
          error.style.display = "block";
          btn.style.display = "none";
        }
        if(email.value == ""){
          email.style.borderColor = "lightgrey";
          // email.style.background = "rgba(27, 25, 25, 0.9)";
          icon1.style.display = "none";
          icon2.style.display = "none";
          error.style.display = "none";
          btn.style.display = "none";
        }
      }
    </script>
   
    

             
                  
</body>
</html>
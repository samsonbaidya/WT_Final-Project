<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <title>REGISTRATION</title>
  <link rel="stylesheet" type="text/css" href="all.min.css">
  <body style="background-image: url(reg5.jpg);  background-repeat: no-repeat; background-attachment: fixed;background-size: 100% 100%; ">
 

    <link rel="stylesheet" type="text/css" href="reg.css">
</head>
<body>  
<center>
 <div class="container">
 <h1 class="rem">Online Polling System</h1><br>
     <form method="POST" action="otp.php" id="form"> 
        <h3 class="neon">REGISTRATION</h3>

       
         
         
        <div>
          <center>
           <div >
        <a  href="permission.php" id="admin">
              <span></span>
              <span></span>
              <span></span>
              <span></span>
             ADMIN REGISTER
            </a>
        <a  href="usersignup.php" id="user">
              <span></span>
              <span></span>
              <span></span>
              <span></span>
             USER REGISTER
            </a>
            <a  href="login.php" id="user">
              <span></span>
              <span></span>
              <span></span>
              <span></span>
             BACK
            </a>
            </div>
          </center>
           
        </div>  
        
      
     


      </form>
</div>

<footer id="main-footer">
        <hr>
        <p>Copyright &copy; Online Polling System 2020  </p>
      </footer>  
  </center>        
             
                  
</body>
</html>
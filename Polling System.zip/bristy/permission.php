<!DOCTYPE html>
<html>
<head>
  <title>Permission for Admin Signup</title>
  <link rel="stylesheet"  href="permission.css">
      <body style="background-image: url(keys.jpg);  background-repeat: no-repeat; background-attachment: fixed;background-size: 100% 100%; ">
</head>
<body>
    <center>
   <div class="container">
      <form method="post" action="permission.php">
        <h2 class="neon">Online Polling System</h2><br><br>
       

  <fieldset>



  <legend><h3><i>Token Number for Admin SignUp</i></h3></legend>
  <form method="post" action="permission.php">
    <p><b>Give the code which is provided for Admin signup</b></p>
    <i class="fa fa-envelope" aria-hidden="true"></i>
          <input type="text" placeholder="Token Number"  name="permission" required> <br><br>
       
  

  <?php 
  if(isset($_POST['cancel'])){
    header("location: homepage.html");
  }
  elseif (isset($_POST['submit'])) {
    $check = $_POST['permission'];
    if ($check ==  12345){ //token=12345
      header("location: adminsignup.php");
    }
    else {
      echo "Permission code doesn't match <br><br>";
    
  }
    
  }
  ?>

       <input class="neon2" type="submit" name="cancel" value="Back">
       <input class="neon1" type="submit" name="submit" value="Check">
   </form>
  </fieldset>
  </div>
   
</center>
 <footer id="main-footer">
        <hr>
        <p>Copyright &copy; Online Polling System 2020  </p>
      </footer>
</body>
</html>
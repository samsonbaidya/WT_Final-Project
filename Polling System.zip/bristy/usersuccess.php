<!DOCTYPE html>
<html>
<head>
  <title>User Signup Successfull</title>
  <link rel="stylesheet"  href="usersuccess.css">
      <body style="background-image: url(u1.jpg);  background-repeat: no-repeat; background-attachment: fixed;background-size: 100% 100%; ">
</head>
<body>
    <center>
   <div class="container">
      <form method="post" action="usersuccess.php">
        <h2 class="neon">Online Polling System</h2><br><br>
       

  <fieldset>


<?php
    session_start();
    if(isset($_SESSION['fname']) && $_SESSION['lname'] && $_SESSION['uname'] && $_SESSION['gender']
       && $_SESSION['number'] && $_SESSION['address'] && $_SESSION['email'] && $_SESSION['age']) {
        echo "<b><i><u>Welcome ".$_SESSION['fname']." ".$_SESSION['lname']."</u><i></b><br></br>";
        echo "<b>You have been successfully registered in the system<b><br>";
        echo "<b>Your Username is: ".$_SESSION['uname']."</b><br>";
        echo "<b>Your Gender is: ".$_SESSION['gender']."</b><br>";
        echo "<b>Your Age is: ".$_SESSION['age']."</b><br>";
        echo "<b>Your Number is: ".$_SESSION['number']."</b><br>";
        echo "<b>Your Address is: ".$_SESSION['address']."</b><br>";
        echo "<b>Your Email is: ".$_SESSION['email']."</b><br>";
        echo "Please logout and log back in.<br><br><br>";
        #echo "<a href='homepage.html'>Go to the home page</a>";
    }
?>


<input class="neon2" type="submit" name="cancel" value="Logout">
       
   </form>
  </fieldset>
  </div>
   
</center>
 <footer id="main-footer">
        <hr>
        <p>Copyright &copy; Online Polling System 2020  </p>
      </footer>
</body>
</center>
</html>
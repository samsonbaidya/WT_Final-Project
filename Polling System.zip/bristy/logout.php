<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>LOGOUT</title>
<link rel="stylesheet" type="text/css" href="logout.css">
 <link href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round" rel="stylesheet">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<body>
<div class="text-center">
  <!-- Button HTML (to Trigger Modal) -->
  <!-- <a href="#myModal" class="trigger-btn" data-toggle="modal">Click to Open Confirm Modal</a> -->
  <div class="container">
    <center><header class="rem">Online Polling System</header></center>
  <form>
  <h1 class="neon">Logout</h1>
 
  <center>
    <div>
      <br>
      <br>
      <a  href="#myModal" class="trigger-btn" data-toggle="modal" id="reg">
              <span></span>
              <span></span>
              <span></span>
              <span></span>
           LOGOUT
            </a>
            </div>  
            </center>
           
  </form>
  
</div>

<!-- Modal HTML -->
<div id="myModal" class="modal fade">
  <div class="modal-dialog modal-confirm">
    <div class="modal-content">
      <div class="modal-header">
        <div class="icon-box">
          <i class="material-icons">&#xE876;</i>
        </div>        
        <h4 class="modal-title">Awesome!</h4> 
      </div>
      <div class="modal-body">
        <p class="text-center">Your have successfully Logout.</p>
      </div>
      <div class="modal-footer">
         <a  href="login.php" class="btn btn-success btn-block" data-dismiss="modal" id="reg">
              <span></span>
              <span></span>
              <span></span>
              <span></span>
           LOGOUT
            </a>
        
      </div>
    </div>
  </div>
</div>     
<footer id="main-footer">
        <hr>
        <p>Copyright &copy; Online Polling System 2020  </p>
      </footer>   
</body>
</html>                            
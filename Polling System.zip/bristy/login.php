<?php
$db = mysqli_connect("localhost", "root", "","company");
$email = "";
$name = "";
$errors = array();
if(isset($_POST['login'])) {
    session_start();
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $password = mysqli_real_escape_string($con, $_POST['password']);
    
    if(count($errors) === 0){
        $encpass = password_hash($password, PASSWORD_BCRYPT);
        $code = rand(999999, 111111);
        $status = "notverified";
        $insert_data = "INSERT INTO usertable (name, email, password, code, status)
                        values('$name', '$email', '$encpass', '$code', '$status')";
        $data_check = mysqli_query($con, $insert_data);
        if($data_check){
            $subject = "Email Verification Code";
            $message = "Your verification code is $code";
            $sender = "From: shahiprem7890@gmail.com";
            if(mail($email, $subject, $message, $sender))
            {
                $info = "We've sent a verification code to your email - $email";
                $_SESSION['info'] = $info;
                header('location: user-otp.php');
                exit();
            }
            else
            {
                $errors['otp-error'] = "Failed while sending code!";
            }
        }
        else
        {
            $errors['db-error'] = "Failed while inserting data into database!";
        }
    }
}

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
	<title>LOGIN</title>
  <link rel="stylesheet" type="text/css" href="all.min.css">
  <script src="https://kit.fontawesome.com/a076d05399.js"></script>

  <body style="background-image: url(log2.jpg);  background-repeat: no-repeat; background-attachment: fixed;background-size: 100% 100%; ">
 

	<link rel="stylesheet" type="text/css" href="login.css">
</head>
<body>

 <div class="container">
  <center><header class="rem">Online Polling System</header></center>
   <form method="POST" action="login.php" id="form"> 
        <h1 class="neon">Login</h1>
  

        <div class="field">
          <i class="fa fa-envelope-o" aria-hidden="true"></i>
          <input onkeyup="check()" id="email" type="text" autocomplete="off" placeholder="Email">
          <div >
             <span class="icons" >
           <i id="danger" class="icon1">❌</i>
          <i id="right" class="icon2">✔️</i> 
          </span>
          </div></div>
     <div class="error-text">
Please Enter Valid Email Address</div>

        <div class="textbox">
          <i class="fa fa-key fa-fw"></i>
          <input type="password"  placeholder="Password" id="myInput" name="pass" value="" required>    
          
          <span class="eye" onclick="myFunction()">
          <i id="hide1" class="fa fa-eye"></i> 
          <i id="hide2" class="fa fa-eye-slash"></i> 
          </span>
          <span id="text"></span>
        </div>   
        <br>&nbsp  
        <div>
          <center>
           <div >
         <button class="btn" name="send">
       LOGIN</button>
             <a  href="reg.php" id="reg">
              <span></span>
              <span></span>
              <span></span>
              <span></span>
             REGISTER
            </a></div>
            <div class="popup"></div>
          </center>
           
        </div>  
        <br>  <br><br> 
        
        <div class="center" >
          <input type="checkbox" name="Remember" checked="checked" ><i id="rem">Remember me ! </i>     
        </div>
        <br>
        <div><center>
           <i id="fpass" >Forget Password </i></center> <a  href="reset.php" class="reset">
              <span></span>
              <span></span>
              <span></span>
              <span></span>
            Reset
            </a> 
        </div>
        <div class="socials">
         <ul>
<li ><i class="fab fa-facebook-f" id="fb"></i></li>
<li><i class="fab fa-twitter" id="twi"></i></li>
<li><i class="fab fa-instagram" id="insta"></i></li>
<li><i class="fab fa-linkedin-in" id="link"></i></li>
<li><i class="fab fa-youtube" id="ytube"></i></li>
</ul>
     </div>
        

      </form>
</div>
 <footer id="main-footer">
        <hr>
        <p>Copyright &copy; Online Polling System 2020  </p>
      </footer>     
<script type="text/javascript">
            function myFunction(){
              var x =document.getElementById("myInput");
              var y =document.getElementById("hide1");
             var z = document.getElementById("hide2");
             if(x.type ==='password'){
              x.type="text";
              y.style.display = "block";
              z.style.display = "none";
             }
             else{
              x.type="password";
              y.style.display = "none";
              z.style.display = "block";
             }
            }
          </script>
           <script type="text/javascript">
           
      const email = document.querySelector("#email");
      const icon1 = document.querySelector(".icon1");
      const icon2 = document.querySelector(".icon2");
      const error = document.querySelector(".error-text");
      const btn = document.querySelector(".btn");
      let regExp = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
      function check(){
        if(email.value.match(regExp)){
          // email.style.
          email.style.borderColor = "#18d635";
          // email.style.background = "#eafaf1";
          icon1.style.display = "none";
          icon2.style.display = "block";
          error.style.display = "none";
          btn.style.display = "block";
        }else{
          email.style.borderColor = "#f31701";
          // email.style.background = "#fceae9";
          icon1.style.display = "block";
          icon2.style.display = "none";
          error.style.display = "block";
          btn.style.display = "none";
        }
        if(email.value == ""){
          email.style.borderColor = "lightgrey";
          // email.style.background = "rgba(27, 25, 25, 0.9)";
          icon1.style.display = "none";
          icon2.style.display = "none";
          error.style.display = "none";
          btn.style.display = "none";
        }
      }
    </script>

       
                  
</body>


</html>